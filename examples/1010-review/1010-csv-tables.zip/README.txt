ENGINEERING REVIEW DATA
Unknown fields are blank. Geometry is mm; weights N; temperature Celsius; pressure MPa.
These CSV tables are an interchange handoff, not a claim that CAESAR directly imports arbitrary CSV.
Use the qualified neutral-file profile for a native CAESAR import candidate.
